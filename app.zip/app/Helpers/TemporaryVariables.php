<?php

namespace App\Helpers;

class TemporaryVariables
{
    public static $authors;
    public static $papers;
    public static $records;
    public static $candidates;

    public static $status = [];
}
